"""Test unitari del progetto."""
